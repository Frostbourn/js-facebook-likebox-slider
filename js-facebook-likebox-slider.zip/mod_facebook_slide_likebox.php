<?php
/**
 * @package    JS Like Box Slider
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * @link       https://jsns.eu
 */
 
//no direct access
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

require( JModuleHelper::getLayoutPath( 'mod_facebook_slide_likebox' ) );
?>